import os
from pathlib import Path

TODO_FILE = Path(__file__).resolve().parent.parent / "TODOLIST.md"

def ensure_todolist():
    if not TODO_FILE.exists():
        with open(TODO_FILE, "w") as f:
            f.write("# TODO List\n\n- [ ] Example task\n")
        return "TODOLIST.md created with example task."
    with open(TODO_FILE, "r") as f:
        content = f.read().strip()
    if not content or all(line.strip().startswith("- [x]") for line in content.splitlines() if line.strip()):
        return "All tasks complete. Safe to proceed."
    return f"Pending tasks:\n{content}"

if __name__ == "__main__":
    print(ensure_todolist())
