import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OPENAPI_FILE = ROOT / "openapi.json"
API_FILE = ROOT / "API_REFERENCE.md"

def generate_api_reference():
    if not OPENAPI_FILE.exists():
        return "openapi.json not found."

    with open(OPENAPI_FILE, "r") as f:
        spec = json.load(f)

    lines = []
    info = spec.get("info", {})
    lines.append(f"# {info.get('title', 'API')} Reference\n")
    lines.append(f"Version: {info.get('version', '')}")
    lines.append(f"Description: {info.get('description', '')}\n")

    if "servers" in spec:
        lines.append("## Servers")
        for server in spec["servers"]:
            lines.append(f"- {server.get('description','')}: `{server.get('url','')}`")
        lines.append("")

    if "paths" in spec:
        for path, methods in spec.items():
            for method, details in methods.items():
                lines.append(f"## {method.upper()} {path}")
                lines.append(f"**Summary:** {details.get('summary','')}")
                lines.append(f"**OperationId:** {details.get('operationId','')}")
                if "responses" in details:
                    lines.append("**Responses:**")
                    for code, resp in details["responses"].items():
                        desc = resp.get("description", "")
                        lines.append(f"- {code}: {desc}")
                lines.append("")

    if "components" in spec and "schemas" in spec["components"]:
        lines.append("## Schemas")
        for name, schema in spec["components"]["schemas"].items():
            lines.append(f"### {name}")
            if "properties" in schema:
                lines.append("```json")
                props = {k: v.get("type","any") for k,v in schema["properties"].items()}
                import json as _json
                lines.append(_json.dumps(props, indent=2))
                lines.append("```")
            if "required" in schema:
                req = ", ".join(schema["required"])
                lines.append(f"**Required fields:** {req}")
            lines.append("")

    API_FILE.write_text("\n".join(lines))
    return f"API_REFERENCE.md updated at {API_FILE}"

if __name__ == "__main__":
    print(generate_api_reference())
