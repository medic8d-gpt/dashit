import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

// Success Metric Block simulation rules
const successMetrics = [
  "Accuracy: Output must be factually correct",
  "Clarity: Output must be coherent and easy to understand",
  "Relevance: Output must directly address the question",
  "Consistency: Must follow persona, tone, and format",
  "Efficiency: Must be concise and avoid unnecessary tokens"
];

// Prebuilt default profiles
const defaultProfiles = {
  "Researcher": {
    purpose: "Research assistant",
    tasks: "Summarize articles",
    success: "Accurate and fact-checked",
    longTermGoals: "Increase productivity",
    persona: "Formal academic researcher",
    proactivity: "Suggest improvements only",
    ambiguity: "Ask clarifying questions",
    style: "Formal and technical",
    knowledge: "Education and tutoring",
    sources: "Academic journals",
    ignore: "Social media opinions",
    reasoning: "Step-by-step logic",
    forbidden: "Political opinions",
    bias: "Corporate jargon",
    tools: "Ask before using",
    conflict: "Refuse and cite rules",
    format: "Markdown table",
    conventions: "Cite sources at the end",
    length: "Concise (under 200 words)",
    structured: "Code blocks with language tags"
  },
  "Engineer": {
    purpose: "Coding expert",
    tasks: "Debug code",
    success: "Technical and detailed",
    longTermGoals: "Reduce errors in work",
    persona: "Pragmatic engineer",
    proactivity: "Always proactive",
    ambiguity: "State limitations and proceed",
    style: "Simple and concise",
    knowledge: "Software development",
    sources: "User-provided files",
    ignore: "Outdated forums",
    reasoning: "Data-driven analysis",
    forbidden: "Hard-coded secrets",
    bias: "Overly optimistic language",
    tools: "Only use safe local tools",
    conflict: "Follow safest option",
    format: "Code blocks",
    conventions: "Always start with TL;DR",
    length: "Adaptive based on task",
    structured: "Downloadable CSV/JSON"
  },
  "Creative": {
    purpose: "Creative partner",
    tasks: "Brainstorm ideas",
    success: "Creative and engaging",
    longTermGoals: "Learn a new skill",
    persona: "Witty creative partner",
    proactivity: "Suggest improvements only",
    ambiguity: "Offer multiple possibilities",
    style: "Conversational and casual",
    knowledge: "Creative writing",
    sources: "General web search",
    ignore: "Unverified snippets",
    reasoning: "Creative exploration",
    forbidden: "Speculative claims",
    bias: "Technical elitism",
    tools: "Free to use trusted APIs",
    conflict: "Suggest alternative",
    format: "Bulleted list",
    conventions: "Provide examples",
    length: "Medium (500 words)",
    structured: "Annotated diagrams"
  }
};

// 20 Questions from the framework with 5 options each (plus free text)
const questions = [
  { key: "purpose", text: "What is the primary role or function of this AI assistant?", options: ["Research assistant","Creative partner","Coding expert","Personal tutor","Project manager"]},
  { key: "tasks", text: "What are the top tasks you will regularly ask this AI to perform?", options: ["Summarize articles","Draft emails","Debug code","Brainstorm ideas","Generate reports"]},
  { key: "success", text: "What does a 'perfect' or successful output look like?", options: ["Accurate and fact-checked","Concise and clear","Creative and engaging","Technical and detailed","Step-by-step explanation"]},
  { key: "longTermGoals", text: "What are your long-term goals for using this AI?", options: ["Increase productivity","Improve writing quality","Learn a new skill","Automate workflows","Reduce errors in work"]},
  { key: "persona", text: "Describe the ideal persona for the AI.", options: ["Formal academic researcher","Witty creative partner","Supportive mentor","Pragmatic engineer","Friendly peer"]},
  { key: "proactivity", text: "What level of proactivity should the AI have?", options: ["Always proactive","Suggest improvements only","Ask before suggesting","Mostly reactive","Purely reactive"]},
  { key: "ambiguity", text: "How should the AI handle ambiguity?", options: ["Ask clarifying questions","Make best-guess assumption","State limitations and proceed","Offer multiple possibilities","Escalate uncertainty back to user"]},
  { key: "style", text: "What communication style should it use?", options: ["Formal and technical","Simple and concise","Conversational and casual","Detailed and verbose","Humorous and light"]},
  { key: "knowledge", text: "What domains or subjects should it be expert in?", options: ["Software development","Business and finance","Health and wellness","Education and tutoring","Creative writing"]},
  { key: "sources", text: "What sources of truth should it use?", options: ["User-provided files","Academic journals","Specific websites","Internal documentation","General web search"]},
  { key: "ignore", text: "What sources should it avoid?", options: ["Social media opinions","Outdated forums","Non-expert blogs","AI-generated content","Unverified snippets"]},
  { key: "reasoning", text: "What reasoning approach should it use?", options: ["Step-by-step logic","Analogy-based reasoning","Data-driven analysis","Creative exploration","Minimalist assumptions"]},
  { key: "forbidden", text: "What topics/content should it absolutely avoid?", options: ["Financial advice","Medical diagnoses","Political opinions","Offensive content","Speculative claims"]},
  { key: "bias", text: "What biases should it avoid?", options: ["Corporate jargon","Overly optimistic language","Cultural assumptions","Technical elitism","Negative framing"]},
  { key: "tools", text: "How should it handle external tools or data?", options: ["Ask before using","Never access external APIs","Always log tool use","Only use safe local tools","Free to use trusted APIs"]},
  { key: "conflict", text: "If instructions conflict with a user request, what should it do?", options: ["Refuse and cite rules","Suggest alternative","Ask for clarification","Follow safest option","Proceed with user override"]},
  { key: "format", text: "What is the default output format?", options: ["Bulleted list","Markdown table","JSON","Formal paragraphs","Code blocks"]},
  { key: "conventions", text: "What recurring formatting rules should it follow?", options: ["Always start with TL;DR","Cite sources at the end","Bold key terms","Use headers for structure","Provide examples"]},
  { key: "length", text: "What is the typical desired length for responses?", options: ["Very short (1-2 sentences)","Concise (under 200 words)","Medium (500 words)","Detailed (1000+ words)","Adaptive based on task"]},
  { key: "structured", text: "How should code/data be presented?", options: ["Code blocks with language tags","Downloadable CSV/JSON","Inline examples","Separate files","Annotated diagrams"]}
];

export default function ProductySurveyApp() {
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);

  const handleChange = (key, value) => {
    setAnswers({ ...answers, [key]: value });
  };

  const handleRun = () => {
    const allAnswered = questions.every((q) => answers[q.key]);
    const smbCheck = allAnswered ? "SMB_CHECK: PASSED" : "SMB_CHECK: INCOMPLETE";
    setResult({ ...answers, selfCheck: smbCheck, metrics: successMetrics });
  };

  const handleRandomProfile = () => {
    const keys = Object.keys(defaultProfiles);
    const randomKey = keys[Math.floor(Math.random() * keys.length)];
    setAnswers(defaultProfiles[randomKey]);
  };

  const handleSetProfile = (profileName) => {
    setAnswers(defaultProfiles[profileName]);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8 space-y-6">
      <h1 className="text-2xl font-bold">Producty 20-Question Setup</h1>
      <div className="flex gap-4 mb-4">
        <Button onClick={handleRandomProfile}>Random Profile</Button>
        {Object.keys(defaultProfiles).map((name) => (
          <Button key={name} onClick={() => handleSetProfile(name)}>
            {name} Profile
          </Button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {questions.map((q) => (
          <Card key={q.key} className="p-4">
            <p className="font-semibold mb-2">{q.text}</p>
            <Select value={answers[q.key] || ""} onValueChange={(val) => handleChange(q.key, val)}>
              <SelectTrigger>
                <SelectValue placeholder="Choose an option" />
              </SelectTrigger>
              <SelectContent>
                {q.options.map((opt) => (
                  <SelectItem key={opt} value={opt}>
                    {opt}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Textarea
              placeholder="Or type your own answer"
              className="mt-2"
              value={answers[q.key] || ""}
              onChange={(e) => handleChange(q.key, e.target.value)}
            />
          </Card>
        ))}
      </div>
      <Button onClick={handleRun} className="w-full">
        Generate Mock Setup
      </Button>
      {result && (
        <Card className="p-4 bg-white shadow">
          <CardContent>
            <h2 className="font-semibold mb-2">Generated Setup</h2>
            <pre className="whitespace-pre-wrap text-sm">{JSON.stringify(result, null, 2)}</pre>
            <h3 className="font-semibold mt-4 mb-2">Self-Check Routine</h3>
            <ul className="list-disc pl-5 text-sm">
              {result.metrics.map((m, i) => (
                <li key={i}>✔️ {m}</li>
              ))}
            </ul>
            <p className="mt-2 font-bold">{result.selfCheck}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
