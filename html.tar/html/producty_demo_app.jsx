import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

// Mock Success Metric Block Evaluation
const successMetrics = [
  "Accuracy: Output must be factually correct",
  "Clarity: Output must be coherent and easy to understand",
  "Relevance: Output must directly address the question",
  "Consistency: Must follow persona, tone, and format",
  "Efficiency: Must be concise and avoid unnecessary tokens"
];

export default function ProductyDemoApp() {
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);

  const handleChange = (field, value) => {
    setAnswers({ ...answers, [field]: value });
  };

  const handleRun = () => {
    // Mock "AI Response" based on inputs
    const mockResponse = `
Persona: ${answers.persona || "Not set"}
Purpose: ${answers.purpose || "Not set"}
Knowledge Scope: ${answers.knowledge || "General knowledge"}
Output Example: ${answers.output || "A clear, concise summary"}

Self-Check Results:\n${successMetrics.map((m) => `✔️ ${m}`).join("\n")}
    `;
    setResult(mockResponse);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Input Side */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-4"
      >
        <h1 className="text-2xl font-bold">Producty Setup Demo</h1>
        <Card className="p-4 space-y-4">
          <Input
            placeholder="Purpose & Goals (What is this AI for?)"
            onChange={(e) => handleChange("purpose", e.target.value)}
          />
          <Input
            placeholder="Persona (Who should the AI be?)"
            onChange={(e) => handleChange("persona", e.target.value)}
          />
          <Input
            placeholder="Knowledge & Scope (What should it know?)"
            onChange={(e) => handleChange("knowledge", e.target.value)}
          />
          <Textarea
            placeholder="Output & Formatting (How should results look?)"
            onChange={(e) => handleChange("output", e.target.value)}
          />
          <Button onClick={handleRun} className="w-full">
            Run Mock AI
          </Button>
        </Card>
      </motion.div>

      {/* Output Side */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h2 className="text-xl font-semibold mb-2">AI Output Simulation</h2>
        <Card className="p-4 bg-white shadow">
          <CardContent>
            {result ? (
              <pre className="whitespace-pre-wrap text-sm">{result}</pre>
            ) : (
              <p className="text-gray-500">Fill in inputs and click Run to see the mock AI response.</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
